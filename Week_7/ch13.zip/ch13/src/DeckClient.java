
public class DeckClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deck myDeck = new Deck(); //create a standard 52-card deck
		//test the print instance method
		myDeck.print();

	}

}
